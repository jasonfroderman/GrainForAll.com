$(document).foundation();

var $body = $('body');
var $stats = $('#stats-and-facts');
var activeSection = "";
var storySwiper;
var statsSwiper;

var viewPorts = {
    'small': 0,
    'medium': 1,
    'large': 2,
    'xlarge': 3,
    'xxlarge': 4
};

var isMobileMenuOpen = $body.hasClass('opened-menu');
var hasMobileMenuMarker = $body.hasClass('mobile-menu-marker');
var currentViewPort = viewPorts[Foundation.MediaQuery.current];
var isDesktopViewPort = currentViewPort >= 2;
var isMobileViewPort = currentViewPort <= 0;


$('[data-magellan]').on('update.zf.magellan', function() {
    var section = $("#jump-menu nav .active").attr('href');
    // console.log(section);

    // When adding sticky to magellan, this bug presented itself.
    // Post to Foundation about it.
    if (this.activeSection != section) {
        this.activeSection = section;

        // console.log(this.activeSection);
    }
});

var reInitToggler = function(){
    $('#jump-menu').foundation('toggle');
    $body.removeClass('opened-menu');
    $body.removeClass('mobile-menu-marker');
};

$('#stay-engaged-wrapper').on('replaced.zf.interchange', function(){

    if($('.mobile-menu-stay-engaged').length){
        $('.mobile-menu-stay-engaged').on('click', function(){
            $('#jump-menu nav').foundation();
            reInitToggler();
        });
    }
});

$('#give-now-wrapper').on('replaced.zf.interchange', function(){

    if($('.mobile-menu-give-now').length){
        $('.mobile-menu-give-now').on('click', function(){
            $('#jump-menu nav').foundation();
            reInitToggler();          
        });
    }
});

/**
 * Grid guides
 */
var showGridGuides = function() {
    $('body').append('<div id="grid-guides">' +
        '<div class="grid-guide-row">' +
        '<div class="grid-guide-column"><div class="grid-guide-column-inner"></div></div>' +
        '<div class="grid-guide-column"><div class="grid-guide-column-inner"></div></div>' +
        '<div class="grid-guide-column"><div class="grid-guide-column-inner"></div></div>' +
        '<div class="grid-guide-column"><div class="grid-guide-column-inner"></div></div>' +
        '<div class="grid-guide-column"><div class="grid-guide-column-inner"></div></div>' +
        '<div class="grid-guide-column"><div class="grid-guide-column-inner"></div></div>' +
        '<div class="grid-guide-column"><div class="grid-guide-column-inner"></div></div>' +
        '<div class="grid-guide-column"><div class="grid-guide-column-inner"></div></div>' +
        '<div class="grid-guide-column"><div class="grid-guide-column-inner"></div></div>' +
        '<div class="grid-guide-column"><div class="grid-guide-column-inner"></div></div>' +
        '<div class="grid-guide-column"><div class="grid-guide-column-inner"></div></div>' +
        '<div class="grid-guide-column"><div class="grid-guide-column-inner"></div></div>' +
        '</div>' +
        '</div>');
};

var hideGridGuides = function() {
    $('#grid-guides').remove();
};


/**
* Copyright 2012, Digital Fusion
* Licensed under the MIT license.
* http://teamdf.com/jquery-plugins/license/
*
* @author Sam Sehnert
* @desc A small plugin that checks whether elements are within
*     the user visible viewport of a web browser.
*     only accounts for vertical position, not horizontal.
*/
(function($) {
  $.fn.visible = function(partial) {
      var $t            = $(this),
          $w            = $(window),
          viewTop       = $w.scrollTop(),
          viewBottom    = viewTop + $w.height(),
          _top          = $t.offset().top,
          _bottom       = _top + $t.height(),
          compareTop    = partial === true ? _bottom : _top,
          compareBottom = partial === true ? _top : _bottom;
    
    return ((compareBottom <= viewBottom) && (compareTop >= viewTop));
  };
})(jQuery);


/**
 * Pie charts
 * Repurposed from Eric Sadowski (http://codepen.io/ejsado/pen/cLrlm/)
 * Had to restructure addSlice so multiple pie charts could exist on each page
 */
function sliceSize(dataNum, dataTotal) {
    return (dataNum / dataTotal) * 360;
}

function addSlice(sliceSize, pieElement, offset, sliceID, color) {
    var elementString = String(pieElement).substring(1);
    $(pieElement).append("<div class='slice " + elementString + sliceID + "'><span></span></div>");
    var offset = offset - 1;
    var sizeRotation = -179 + sliceSize;
    $("." + elementString + sliceID).css({"transform": "rotate(" + offset + "deg) translate3d(0,0,0)"});
    $("." + elementString + sliceID + " span").css({"transform": "rotate(" + sizeRotation + "deg) translate3d(0,0,0)", "background-color": color});
}

function iterateSlices(sliceSize, pieElement, offset, dataCount, sliceCount, color) {
    var sliceID = "s" + dataCount + "-" + sliceCount;
    var maxSize = 179;

    if(sliceSize <= maxSize) {
        addSlice(sliceSize, pieElement, offset, sliceID, color);
    } else {
        addSlice(maxSize, pieElement, offset, sliceID, color);
        iterateSlices(sliceSize - maxSize, pieElement, offset + maxSize, dataCount, sliceCount + 1, color);
    }
}

function createPie(dataElement, pieElement) {
    var listData = [];
    $(dataElement + " span").each(function() {
        listData.push(Number($(this).html()));
    });

    var listTotal = 0;
    for (var i=0; i < listData.length; i++) {
        listTotal += listData[i];
    }
        
    var offset = 0;
    var color = [
        "rgb(78, 143, 204)",  
        "rgb(6, 36, 67)"
    ];

    for(var i=0; i < listData.length; i++) {
        var size = sliceSize(listData[i], listTotal);
        iterateSlices(size, pieElement, offset, i, 0, color[i]);
        $(dataElement + " li:nth-child(" + (i+1) + ")").css("border-color", color[i]);
        offset += size;
    }
}

function animateStudentNumber(){
    $('.count').each(function () {
        $(this).prop('Counter', 0).animate({
            Counter: $(this).text()
        }, {
            duration: 1500,
            easing: 'swing',
            step: function (now) {
                $(this).text(Number(Math.ceil(now)).toLocaleString('en'));
            }
        });
    });
}

var triggerAllAnimations = function(){
    createPie(".pie-facts-1-data", "#pie-facts-1-chart");
    createPie(".pie-facts-3-data", "#pie-facts-3-chart");
    animateStudentNumber();
    $body.addClass('graphs-animated');
};

var renderAllAnimations = function(){
    var animated = $body.hasClass('graphs-animated');

    if($stats.visible(true) && !animated){
        triggerAllAnimations();
    }
};

$(window).scroll(function(event){
    renderAllAnimations();
});

$(window).load(function(event){
    renderAllAnimations();
});

// Temp Smooth Scroll
// $(function() {
//     $('a[href*="#"]:not([href="#"])').click(function() {
//         if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
//             var target = $(this.hash);
//             target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
//             if (target.length) {
//                 $('html, body').animate({
//                     scrollTop: target.offset().top
//                 }, 1000);
//                 return false;
//             }
//         }
//     });
// });

// Stories and Facts
var adrianSimien = {
    url: './assets/img/mbu-stories-adrian.jpg',
    header: 'To Heal & Bring Life',
    subtitle: 'Adrian Simien, MBU Graduate of 2013',
    content: 'Adrian left his gang-ridden neighborhood in Compton, Calif. to attend MBU on scholarship in hope that a degree would improve the life of his family. Once here, he realized he could achieve more than a degree. The science department’s community supported Adrian to pursue a career in medicine. His success and ambition landed Adrian a full-ride scholarship to medical school. Upon graduating in 2017, Adrian will pursue a residency to further his ability enable his patients to live a fulfilling life like the one MBU helped him realize.'
};

var jamesGalyon = {
    url: './assets/img/mbu-stories-james.jpg',
    header: 'To Lead Amid Darkness',
    subtitle: 'Dr. James Galyon, MBU Graduate of 1990',
    content: 'When James came to MBU on scholarship, he was a self-described wild-child without direction. MBU professors mentored James, showing him the way to deepen his relationship with Christ. James realized he wanted to share the power of the Gospel to others as his professors revealed to him. Since graduating from MBU, Galyon has received a Ph.D. and three master\'s degrees. He now serves as a decorated chaplain for the U.S. Army at Ft. Hood, Tex., sharing the hope of Christ in darkness to our battle-worn soldiers.'
};

var tanyaDrochner = {
    url: './assets/img/mbu-stories-tanya.jpg',
    header: 'A Light for the Future',
    subtitle: 'Tanya Drochner, MBU Student',
    content: 'Determined and bright, Tanya knew she needed a college education to better the lives of others. The passion to serve others was passed on to her by her parents--Peruvian missionaries. Her parents\' lack of a regular salary left Tanya in need of significant financial support to attend a university. Through the help of generous donors, Tanya is studying education at Missouri Baptist University. After graduating, Tanya plans on teaching children math and science, and giving the generation of students to come the chance to realize their dreams.'
};

// Set the initial background image
$('.section-stories').css('background-image', 'url(' + adrianSimien.url + ')');

var shiftImages = function(){
    var $topImage = $('.section-stories');
    var $bottomImage = $('.prev-background-image');
    var $currentBg = $topImage.css('background-image');

    $bottomImage.css('background-image', $currentBg);
};

var toggleSelectors = function(){
    var $targetEl = $(event.target);
    var $parentEl = $targetEl.parent();

    $('.story-selector').removeClass('selected');
    $parentEl.addClass('selected');
};

var pickStory = function(event){
    var $backgroundImage = $('.section-stories');
    var $header = $('.story-headline');
    var $subtitle = $('.story-student-name');
    var $content = $('.story-content');
    
    shiftImages();
    toggleSelectors();

    if($(this).hasClass('adrian-link')){
        $backgroundImage.css('background-image', 'url(' + adrianSimien.url + ')');
        $header.html(adrianSimien.header);
        $subtitle.html(adrianSimien.subtitle);
        $content.html(adrianSimien.content);
    }
    if($(this).hasClass('james-link')){
        $backgroundImage.css('background-image', 'url(' + jamesGalyon.url + ')');
        $header.html(jamesGalyon.header);
        $subtitle.html(jamesGalyon.subtitle);
        $content.html(jamesGalyon.content);
    }
    if($(this).hasClass('tanya-link')){
        $backgroundImage.css('background-image', 'url(' + tanyaDrochner.url + ')');
        $header.html(tanyaDrochner.header);
        $subtitle.html(tanyaDrochner.subtitle);
        $content.html(tanyaDrochner.content);
    }
};


$('#stories-and-facts').on('replaced.zf.interchange', function(data) {
    storySwiper = new Swiper('.swiper-container', {
        pagination: '.swiper-pagination',
        paginationClickable: true,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev'
    });

    $('#stories-and-facts').foundation();

    if($('.story-selector')){
        $('.story-selector').on('click', pickStory);
    }
});


/**
 * Interchange stats and facts swiper
 */
$('#stats-and-facts').on('replaced.zf.interchange', function(data){
    statsSwiper = new Swiper('.swiper-container.section-facts', {
        pagination: '.swiper-pagination.stats',
        paginationClickable: true
    });
  
    $('.section-facts').foundation();
    $body.removeClass('graphs-animated');
    renderAllAnimations();
});



/**
 * Subscribe and Donate Forms Section
 */
var isDesktop, isMobile;
var $subscribeBtnWrapper = $('.subscribe-btn-wrapper');
var $donateBtnWrapper = $('#donate-btn-wrapper');

// Subscribe Forms
var openSubscribeForm = function(event){
    var $formWrapper = $('.section-give-now');

    if(!$formWrapper.hasClass('subscribe-open')){
        $formWrapper.removeClass('give-now-open');
        $formWrapper.addClass('subscribe-open');
    } else {
        $formWrapper.removeClass('subscribe-open');
    }
};

var openSubscribeModal = function(event){
    $('.mobile-subscribe').foundation();
};

var determineAndBindSubscribeHandlers = function(){
    if($('.mobile-subscriber').length){
        $('.mobile-subscribe').on('click', openSubscribeModal);
        $('.mobile-menu-stay-engaged').on('click', openSubscribeModal);
    } 
    if($('.subscribe-btn').length){
        $('.cta-learn-more').on('click', openSubscribeForm);
        $('.menu-stay-engaged').on('click', openSubscribeForm);
        $('.subscribe-btn').on('click', openSubscribeForm);
    }
};

$subscribeBtnWrapper.on('replaced.zf.interchange', function(event){
    determineAndBindSubscribeHandlers();
});

//Donate Forms
var createModalInstance = function(element){
    var revealModal = new Foundation.Reveal(element);
};

var addCloseModalBtn = function(){
    return '<div class="close-button-wrapper"><button class="close-button donate-close-btn" data-close aria-label="Close modal" type="button"><span aria-hidden="true">&times;</span></button></div>';
};

$('#bbox-root').on('DOMNodeInserted', function(event){
    this.lastEvent = this.lastEvent || 0;
    this.target = $(event.target);
    this.isFirstEvent = event.timeStamp - this.lastEvent > 200;

    if (this.target.is('#mongo-form') && this.isFirstEvent) {
        var $donateForm = $('#mongo-form');
        var $donateModal = $('#donate-modal-wrapper');

        // Wait on when blackbaud's async operations and DOM loading is complete
        setTimeout(function(){
            $donateModal.append(addCloseModalBtn);
            $donateForm.clone().appendTo('#donate-modal-wrapper');
            createModalInstance($donateModal);
        }, 1000);
    }

    this.lastEvent = event.timeStamp;
});

var openDonateForm = function(event){
    var $formWrapper = $('.section-give-now');

    if(!$formWrapper.hasClass('give-now-open')){
        $formWrapper.removeClass('subscribe-open');
        $formWrapper.addClass('give-now-open');
    } else {
        $formWrapper.removeClass('give-now-open');
    }
};

var bindDonateFormHandler = function(){
    if($('.give-now-btn').length){
        $('.menu-give-now').on('click', openDonateForm);
        $('.cta-give-now').on('click', openDonateForm);
        $('.give-now-btn').on('click', openDonateForm);
    }
};

$donateBtnWrapper.on('replaced.zf.interchange', function(event){
    bindDonateFormHandler();
});

// Gets called by bbox script
window.bboxInit = function() {
    bbox.showForm('027f08bf-739f-4b6c-9012-4fd97a7454f1');
};

(function () {
    var e = document.createElement('script'); e.async = true;      
    e.src = 'https://bbox.blackbaudhosting.com/webforms/bbox-min.js';      
    document.getElementsByTagName('head')[0].appendChild(e);
} ());


/**
 * Mobile Menu Logic
 */
$('.button-menu').on('click', function(event){
    $body.toggleClass('opened-menu');
    $body.toggleClass('mobile-menu-marker');
});

$('#jump-menu li a').on('click', function(event) {
    var isSmallViewPort = Foundation.MediaQuery.current === 'small';
    
    if (isSmallViewPort) {
        reInitToggler();
    }
});

var checkResizeForMenuStatus = function(){
    if(isDesktopViewPort && isMobileMenuOpen){
        $body.removeClass('opened-menu');
    }
    if(isMobileViewPort && hasMobileMenuMarker){
        $body.addClass('opened-menu');
    }
};

$(window).resize(function(){
    checkResizeForMenuStatus();
});


$('form.subscribe').submit(function(e){
  e.preventDefault();
  subscribeUser();
});

function subscribeUser() {
  var name = $('form.subscribe').find('#subscriber-name').val();
  var email = $('form.subscribe').find('#subscriber-email').val();

  $('#subscribe-form-status').removeClass('active');

  $.getJSON('http://grain-api.herokuapp.com/mailchimp-subscribe?email=' + email + '&callback=?', function(data) {
    if (data.code == 200) {
      $('#subscribe-form-status').html('Thanks for signing up to stay engaged!');
    }
    else if (data.code == -100) {
      $('#subscribe-form-status').html('Invalid email address');
    }
    else if (data.code == 214) {
      $('#subscribe-form-status').html('This email address is already subscribed');
    }
    else {
      $('#subscribe-form-status').html('Error subscribing');
    }

    $('#subscribe-form-status').addClass('active');
  });
};
